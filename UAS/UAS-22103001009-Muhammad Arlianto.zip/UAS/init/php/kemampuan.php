<?php  
class Kemampuan extends CV
{
    public $skill1;
    public $skill2;
    public $skill3;
    public $skill4;

    function __construct( $skill1, $skill2, $skill3, $skill4)
    {
        $this->skill1 = $skill1;
        $this->skill2 = $skill2;
        $this->skill3 = $skill3;
        $this->skill4 = $skill4;

    }
 
    function skill1()
    {
        return $this->skill1;
    }
    function skill2()
    {
        return $this->skill2;
    }
    function skill3()
    {
        return $this->skill3;
    }
    function skill4()
    {
        return $this->skill4;
    }

}
$kemampuan = new Kemampuan("HTML", "CSS", "Javascript", "PHP");
?>