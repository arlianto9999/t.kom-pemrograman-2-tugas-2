<?php
require 'init/init.php';
$biodataDiri = new BiodataDiri("Muhammad Arlianto", "Palangka Raya", "arlianto9999@gmail.com",  "085705542193");
$kemampuan = new Kemampuan("HTML", "CSS", "Javascript", "PHP");
$pendidikan = new Pendidikan("Muhammad Arlianto", "SMA PGRI 2 Palangka Raya");
$experience = new PengalamanKerja("Muhammad Arlianto", "Bahalap Hotel", "2019-2020", "Pencuci Piring");

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Curriculum Vitae Muhammad Arlianto</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="container">
        <div class="container1">
            <div class="path1">
            </div>
            <h1>Curriculum Vitae</h1>

            <div class="path2">
                <h2><u>RESUME</u></h2>
                <p>Github</p>
                <p>Instagram</p>
                <p>TikTok</p>
            </div>
            <div class="path3">
                <h2><u>CONTACT</u></h2>
                <p>Whatsapp</p>
                <p>Telegram</p>
                <p>Dicord</p>
            </div>
        </div>

        <div class="section1">
            <h2>Informasi Pribadi</h2>
            <p>Nama: <?php echo $biodataDiri->name(); ?></p>
            <p>Alamat: <?php echo $biodataDiri->location(); ?></p>
            <p>Email: <?php echo $biodataDiri->email(); ?></p>
            <p>Telepon: <?php echo $biodataDiri->contactme(); ?></p>
        </div>

        <div class="section2">
            <h2>Pendidikan</h2>
            <h3><?php echo $pendidikan->sma() ?></h3>
            <p>Tahun: 2015 - 2018</p>
            <p>Jurusan: IPA</p>
        </div>

        <div class="section3">
            <h2>Pengalaman Kerja</h2>
            <h3><?php echo $experience->work(); ?></h3>
            <p>Tahun: <?php echo $experience->year(); ?></p>
            <p>Posisi: <?php echo $experience->position(); ?></p>
        </div>

        <div class="section4">
            <h2>Keterampilan</h2>
            <p><?php echo $kemampuan->skill1(); ?></p>
            <p><?php echo $kemampuan->skill2(); ?></p>
            <p><?php echo $kemampuan->skill3(); ?></p>
            <p><?php echo $kemampuan->skill4(); ?></p>
        </div>

        <div class="section5">
            <h2>Tentang Saya</h2>
            <p>I am an IT with experience as a software support specialist and system/network technician student. A person who is very thorough, creative, innovative, efficient and skilled in operating various IT support platforms.

Have good communication skills and able to explain complex software issues in easy-to-understand terms.</p>
        </div>
    </div>
</body>

</html>