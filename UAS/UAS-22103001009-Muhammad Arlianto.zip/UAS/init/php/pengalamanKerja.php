<?php  
class PengalamanKerja extends CV
{
    public $work;
    public $year;
    public $position;
    function __construct($name, $work, $year, $position)
    {
        parent::__construct($name);
        $this->work = $work;
        $this->year = $year;
        $this->position = $position;
    }
    function name()
    {}
    function work()
    {
        return $this->work;
    }
    function year()
    {
        return $this->year;
    }
    function position()
    {
        return $this->position;
    }
}
$experience = new PengalamanKerja("Muhammad Arlianto", "Bahalap Hotel", "2019-2020", "Pencuci Piring");
?>