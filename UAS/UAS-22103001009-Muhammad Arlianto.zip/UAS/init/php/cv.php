<?php 
abstract class CV
{
    public $name;

    function __construct($name)
    {
        $this->name = $name;

    }

    // abstract function name();
}
?>